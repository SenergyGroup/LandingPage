If you ever want to reset the settings to default, see below.

Window Title (e.g. Chat.exe): "Messenger

Font Size (px): 14

Title Bar Color (Gradient Start): #245edb

Chat Background Color: #FFFFFF

Message Text Color: #000000