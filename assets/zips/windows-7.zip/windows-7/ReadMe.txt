If you ever want to reset the settings to default, see below.

Window Title: Instant Messenger

Font Size (px): 21

Theme Tint (Base Color): #143241

Chat Background Color: #FFFFFF

Message Text Color: #000000