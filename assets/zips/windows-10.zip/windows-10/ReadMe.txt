If you ever want to reset the settings to default, see below.

